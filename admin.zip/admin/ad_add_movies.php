<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

session_start();
if (!isset($_SESSION['admin'])) {
  header('Location: ad_login.php');
  exit;
}

include '../db_connect.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $movie_name = trim($_POST['movie_name']);
  $movie_img = $_POST['movie_img'];
  $available_in = $_POST['available_in'];
  $language = trim($_POST['language']);
  $duration = $_POST['duration'];
  $type = $_POST['type'];
  $cert = trim($_POST['certification']);
  $release = $_POST['release_date'];
  $price = intval($_POST['movie_price']);
  $description = $_POST['description'];
  $cast = $_POST['cast'];
  $cast_img = $_POST['cast_img'];
  $trailer = $_POST['trailer'];
  $gradient = "default"; // you can modify as needed

  if ($movie_name === '') $errors[] = "Movie name is required.";

  if (empty($errors)) {
    $sql = "INSERT INTO movies (movie_name, movie_img, available_in, language, duration, type, certification, release_date, movie_price, description, `cast`, cast_img, trailer, gradient) 
                VALUES ('$movie_name', '$movie_img', '$available_in', '$language', '$duration', '$type', '$cert', '$release', '$price', '$description', '$cast', '$cast_img', '$trailer', '$gradient')";
    if ($conn->query($sql) === TRUE) {
      echo "<script>alert('Movie Added Successfully!'); window.location.href='ad_add_movies.php';</script>";
    } else {
      $errors[] = "DB Error: " . $conn->error;
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Movie - CineBook Admin</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial;
      background: #f5f6fc;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* HEADER */
    .header {
      background: linear-gradient(90deg, #8e2de2, #4a00e0);
      color: white;
      padding: 15px 25px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 22px;
      font-weight: bold;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    }

    .logout-btn {
      color: white;
      font-size: 18px;
      text-decoration: none;
      font-weight: bold;
    }

    /* LAYOUT */
    .layout {
      display: flex;
      flex: 1;
      min-height: calc(100vh - 60px);
    }

    /* SIDEBAR */
    .sidebar {
      width: 240px;
      background: #1d1b31;
      padding-top: 20px;
      color: white;
      flex-shrink: 0;
    }

    .sidebar a {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 20px;
      font-size: 17px;
      color: white;
      text-decoration: none;
      transition: 0.25s;
    }

    .sidebar a:hover {
      background: #2e2b49;
      padding-left: 25px;
    }

    .icon {
      font-size: 22px;
      min-width: 30px;
      text-align: center;
    }

    /* CONTENT */
    .content {
      flex: 1;
      padding: 30px;
    }

    .page-title {
      font-size: 28px;
      font-weight: bold;
      color: #333;
      margin-bottom: 20px;
    }

    /* CARD FORM */
    .card {
      background: white;
      border-radius: 14px;
      padding: 25px;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);
      max-width: 900px;
      margin-top: 20px;
    }

    .card label {
      font-weight: bold;
      display: block;
      margin-bottom: 6px;
    }

    .card input,
    .card textarea {
      width: 100%;
      padding: 10px;
      margin-bottom: 12px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 15px;
    }

    .card button {
      padding: 12px 20px;
      background: #6a11cb;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: 0.3s;
    }

    .card button:hover {
      background: #2575fc;
    }

    /* ERROR MESSAGES */
    .errors {
      background: #fee;
      border: 1px solid #f99;
      padding: 10px;
      border-radius: 6px;
      margin-bottom: 15px;
    }

    /* FOOTER */
    .footer {
      background: #1d1b31;
      color: white;
      text-align: center;
      padding: 15px 0;
      font-size: 16px;
      margin-top: auto;
    }

    /* RESPONSIVE */
    @media (max-width:900px) {
      .sidebar {
        width: 80px;
      }

      .sidebar a span {
        display: none;
      }

      .sidebar a {
        justify-content: center;
      }
    }

    @media (max-width:768px) {
      .content {
        padding: 20px;
      }
    }
  </style>
</head>

<body>

  <!-- HEADER -->
  <div class="header">
    <div>📽️ CineBook Admin Panel</div>

  </div>

  <!-- LAYOUT -->
  <div class="layout">

    <!-- SIDEBAR -->
    <div class="sidebar">
      <a href="dashboard.php"><span class="icon material-icons">dashboard</span><span>Dashboard</span></a>
      <a href="ad_movies.php"><span class="icon material-icons">movie</span><span>Movies</span></a>
      <a href="ad_cinemas.php"><span class="icon material-icons">theaters</span><span>Cinemas</span></a>
      <a href="ad_users.php"><span class="icon material-icons">people</span><span>Users</span></a>
      <a href="logout.php" style="color:#ff4d4d;"><span class="icon material-icons">logout</span><span>Logout</span></a>
    </div>

    <!-- CONTENT -->
    <div class="content">
      <h2 class="page-title">Add New Movie</h2>

      <?php if (!empty($errors)): ?>
        <div class="errors">
          <?php foreach ($errors as $e) echo "<div>" . htmlspecialchars($e) . "</div>"; ?>
        </div>
      <?php endif; ?>

      <div class="card">
        <form method="post" enctype="multipart/form-data">
          <label>Movie Name</label>
          <input type="text" name="movie_name" required>

          <label>Poster (filename)</label>
          <input type="text" name="movie_img">

          <label>Language</label>
          <input type="text" name="language">

          <label>Certification</label>
          <input type="text" name="certification">

          <label>Price (Rs)</label>
          <input type="number" name="movie_price" min="0">

          <label>Release Date</label>
          <input type="date" name="release_date">

          <label>Available In (e.g., 2D)</label>
          <input type="text" name="available_in">

          <label>Duration (e.g., 2h 10m)</label>
          <input type="text" name="duration">

          <label>Type</label>
          <input type="text" name="type">

          <label>Cast (comma separated)</label>
          <input type="text" name="cast">

          <label>Cast Img (comma separated)</label>
          <input type="text" name="cast_img">

          <label>Trailer URL</label>
          <input type="text" name="trailer">

          <label>Description</label>
          <textarea name="description" rows="6"></textarea>

          <button type="submit">Add Movie</button>
        </form>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    © 2025 CineBook | Admin Panel
  </div>

</body>

</html>